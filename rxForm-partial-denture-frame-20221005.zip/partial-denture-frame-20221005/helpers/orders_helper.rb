module OrdersHelper
  def order_form_label(disable)
    if disable
      "ml-2 text-gray-400"
    else
      "ml-2"
    end
  end

  def order_form_label_header_wrap(disable)
    if disable
      "text-3xl mb-2 bg-gray-100 px-2 uppercase"
    else
      "text-3xl mb-2 bg-gray-100 px-2 uppercase"
    end
  end

  def order_form_label_header(disable)
    if disable
      "mb-2 text-2xl font-semibold"
    else
      "mb-2 text-2xl font-semibold"
    end
  end

  def order_form_label_wrap_img(disable)
    if disable
      "rounded-lg text-gray-400 border-gray-900 p-2 bg-gray-100 ml-0"
    else
      "rounded-lg text-gray-400 border-gray-900 p-2 bg-gray-100 ml-0"
    end
  end

  def order_form_label_wrap_all(disable)
    if disable
      "flex flex-col items-center rounded-lg p-2 text-center"
    else
      "flex flex-col items-center rounded-lg p-2 text-center"
    end
  end

  def order_form_label_with_img(disable)
    if disable
      "mt-2 font-semibold rounded-lg text-sm text-gray-400"
    else
      "mt-2 font-semibold rounded-lg text-sm text-gray-600"
    end
  end

  def label_class(disable)
    if disable
      "text-gray-400"
    else
      ""
    end
  end

  def order_form_text_field_label(disable)
    if disable
      "ml-2 text-gray-400 bg-white border border-pangea-border-light-gray rounded px-4 py-2 rounded-lg focus:outline-none w-48"
    else
      "ml-2 bg-white border border-pangea-border-light-gray rounded px-4 py-2 rounded-lg focus:outline-none w-48"
    end
  end

  def order_header_form_text_field_label(disable)
    if disable
      "text-gray-400 bg-white border border-pangea-border-light-gray px-4 py-2 rounded-lg focus:outline-none"
    else
      "bg-white border border-pangea-border-light-gray px-4 py-2 rounded-lg focus:outline-none"
    end
  end

  def order_header_form_date_field_label(disable)
    if disable
      "text-gray-400 bg-white border border-pangea-border-light-gray px-4 py-2 rounded-lg focus:outline-none date-picker cursor-default"
    else
      "border border-pangea-border-light-gray px-4 py-2 rounded-lg focus:outline-none date-picker"
    end
  end

  def veneer_design_style_label(index)
    if index == CrownAndBridge.veneer_design_styles[:veneer_full_countour_design]
      "Full Countour Design"
    else
      "Cutback Design"
    end
  end

  def occurusal_contact_label(index, label)
    if index == CrownAndBridge.occlusals[:foil_relief_1]
      "#1 Foil Relief"
    elsif index == CrownAndBridge.occlusals[:foil_relief_2]
      "#2 Foil Relief"
    elsif index == CrownAndBridge.occlusals[:foil_relief_3]
      "#3 Foil Relief"
    else
      label
    end
  end

  def pontic_design_label(index, label)
    if index == CrownAndBridge.pontic_designs[:sanitary_hygenic]
      "Sanitary/hygenic"
    elsif index == CrownAndBridge.pontic_designs[:saddle_ridge_lap]
      "Saddle-ridge-lap"
    elsif index == CrownAndBridge.pontic_designs[:modified_ridge_lap]
      "Modified ridge-lap"
    else
      label
    end
  end

  def crown_and_bridge_image_url(file_name, disabled)
    if disabled
      file_name = "disabled_#{file_name}"
    else
      file_name
    end
    "order_form/#{file_name}"
  end

  def complete_denture_image_url(file_name, disabled)
    if disabled
      file_name = "disabled_#{file_name}"
    else
      file_name
    end
    "order_form/complete_denture/#{file_name}"
  end

  def ortho_appliance_image_url(file_name, disabled)
    if disabled
      file_name = "disabled_#{file_name}"
    else
      file_name
    end
    "order_form/ortho_appliance/#{file_name}"
  end

  def implant_image_url(file_name, disabled)
    if disabled
      file_name = "disabled_#{file_name}"
    else
      file_name
    end
    "order_form/implant/#{file_name}"
  end

  def partial_denture_image_url(file_name, disabled)
    if disabled
      file_name = "disabled_#{file_name}"
    else
      file_name
    end
    "order_form/partial_denture/#{file_name}"
  end

  def other_image_url(file_name, disabled)
    if disabled
      file_name = "disabled_#{file_name}"
    else
      file_name
    end
    "order_form/other/#{file_name}"
  end

  def surgical_drilling_protocol_guide_label(option)
    if SurgicalGuide.drilling_protocol_guides[option] == SurgicalGuide.drilling_protocol_guides[:pilot_drilling_surgical_guide]
      "Pilot drilling surgical guide (No prosthetics design option)"
    else
      option.titleize
    end
  end

  def surgical_guide_type_label(option)
    if SurgicalGuide.surgical_guide_types[option] == SurgicalGuide.surgical_guide_types[:bone_reduction_guide]
      "Bone Reduction Guide (option for edentulous case)"
    else
      option.titleize
    end
  end

  def surgical_guide_type_of_files_label(option)
    if SurgicalGuide.type_of_files[option] == SurgicalGuide.type_of_files[:surgical_guide_file_only]
      "Surgical guide file only (stl)"
    elsif SurgicalGuide.type_of_files[option] == SurgicalGuide.type_of_files[:surgical_guide_file_include_all_design_files]
      "Surgical guide file include all design files (for same-day teeth)"
    end
  end

  def three_dimension_model_design_option_label(option)
    if ThreeDimensionPrintModelDesign.three_dimension_print_model_design_types[option] == ThreeDimensionPrintModelDesign.three_dimension_print_model_design_types[:diagnostic_wax_ups]
      "Diagnostic wax-ups"
    elsif ThreeDimensionPrintModelDesign.three_dimension_print_model_design_types[option] == ThreeDimensionPrintModelDesign.three_dimension_print_model_design_types[:implant_model_digital_lab_analog]
      "Implant model + digital lab analog"
    else
      option.titleize
    end
  end

  def other_option_label(option)
    if Other.other_design_types[option] == Other.other_design_types[:individual_custom_tray_denture]
      "Individual custom tray (Denture & Crown)"
    elsif Other.other_design_types[option] == Other.other_design_types[:implant_model_digital_lab_analog]
      "Implant model + digital lab analog"
    elsif Other.other_design_types[option] == Other.other_design_types[:individual_custom_tray_implant_site]
      "Individual custom tray (Implant site)"
    elsif Other.other_design_types[option] == Other.other_design_types[:diagnostic_wax_ups]
      "Diagnostic wax-ups"
    else
      option.titleize
    end
  end

  def implant_label(disable)
    if disable
      "w-20 text-gray-300 bg-white border border-pangea-light-gray px-4 py-2 rounded-lg focus:outline-none"
    else
      "w-20 bg-white border border-pangea-light-gray px-4 py-2 rounded-lg focus:outline-none"
    end
  end

  def implant_header_label(disable)
    if disable
      "mx-2 bg-white text-gray-300 border border-pangea-light-gray px-4 py-2 rounded-lg focus:outline-none w-full"
    else
      "mx-2 bg-white border border-pangea-light-gray px-4 py-2 rounded-lg focus:outline-none w-full"
    end
  end


  def ortho_clear_aligner_label(option)
    if OrthoAppliance.clear_aligners[option] == OrthoAppliance.clear_aligners[:models]
      "Models (Designer will provide you all stl files for each stages models)"
    else
      "Retainers (Designer will provide you all stl files for each stages retainers)"
    end
  end

  def crown_select_type_label(option)
    if CrownAndBridge.select_types[option] == CrownAndBridge.select_types[:single_unit]
      "Single Unit / On-lay & In-lay"
    elsif CrownAndBridge.select_types[option] == CrownAndBridge.select_types[:splinted_type]
      "Splinted Type / Maryland Bridge"
    else
      "Full Arch / implant All on X case"
    end
  end

end
