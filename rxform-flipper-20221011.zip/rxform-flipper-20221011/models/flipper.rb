class Flipper < ApplicationRecord
  enum type_of_files: [:flipper_base_only, :monoblock, :teeth_with_flipper_base]
  enum teeth_type: [:singles, :splinted]
  has_one :order, :as => :orderable
  validate :validate_select_options

  def validate_select_options
    if !maxillary_mandibular_upper && !maxillary_mandibular_lower
      errors.add(:base, 'Please select any of maxillary/mandibular')
    end
  end

  def calculate_task_number
    tasks = 0
    if maxillary_mandibular_upper
      tasks += 1
    end

    if maxillary_mandibular_lower
      tasks += 1
    end
    return tasks
  end

  def calculate_sub_total
    service_fee * calculate_task_number
  end

  def service_fee
    order.service_product.get_service_fee("service_fee").price
  end
end
