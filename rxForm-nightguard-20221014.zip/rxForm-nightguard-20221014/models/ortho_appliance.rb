class OrthoAppliance < ApplicationRecord
  has_one :order, :as => :orderable
  enum ortho_appliance_type: [:night_guard, :essix_retainer, :nti, :deprogrammer]
  enum nti: [:"2-2", :"3-3"]
  enum deprogrammer: [:type]
  enum types_of_file: [:flat, :canine_guidance, :anterior_guidance]
  enum setting: [:splint_thickness, :occlusion_open, :retention, :offset_from_teeth_to_splint]

  validates :ortho_appliance_type, presence: { message: "Please select one of options" }

  def calculate_task_number
    tasks = 1
    return tasks
  end

  def calculate_sub_total
    service_fee * calculate_task_number
  end

  def service_fee
    order.service_product.get_service_fee(ortho_appliance_type).price
  end
end
